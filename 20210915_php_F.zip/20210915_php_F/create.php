<?php
// データの受け取り
$name = $_POST["name"];
$sex = $_POST["sex"];

// データ1件を1行にまとめる（最後に改行を入れる）
$write_data = array($name,$sex);

// ファイルを開く．引数が`a`である部分に注目！
$file = fopen('data/an.csv', 'w');
//ストリームフィルタ指定
stream_filter_prepend($file,'convert.iconv.utf-8/cp932'); 
// ファイルをロックする
flock($file, LOCK_EX);

// 指定したファイルに指定したデータを書き込む
fputcsv($file, $write_data);

// ファイルのロックを解除する
flock($file, LOCK_UN);
// ファイルを閉じる
fclose($file);

// 
header("Location:read.php");
<?php
// これはPHPの配列
$hoge_array = ['PHP', 'JS', 'Rust', 'COBOL'];
?>

<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8" />
	<form action="create.php" method="POST">
		<div>
			名前: <input type="text" name="name">
		</div>
		<div>
			性別: <input type="text" name="sex">
		</div>
		<div>
			<button>submit</button>
		</div>
	</form>
</head>


</html>
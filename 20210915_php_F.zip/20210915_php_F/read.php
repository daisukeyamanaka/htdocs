<?php
//https://php-archive.net/php/csv-tsv-array/
setlocale(LC_ALL, 'ja_JP.UTF-8');
 
$data = file_get_contents("data/an.csv");
$data = mb_convert_encoding($data, 'UTF-8', 'sjis-win');
$temp = tmpfile();
$meta = stream_get_meta_data($temp);
 
fwrite($temp, $data);
rewind($temp);
 
$file = new SplFileObject($meta['uri']);
$file->setFlags(SplFileObject::READ_CSV);
 
$csv  = array();
 
foreach($file as $line) {
    $csv[] = $line;
}
 
fclose($temp);
$file = null;
 
var_dump($csv);